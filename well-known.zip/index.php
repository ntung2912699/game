<?php
session_start();
include('./includes/tlca_world.php');
$check=$tlca_do->load('class_check');
$class_index=$tlca_do->load('class_index');
$param_url = parse_url($_SERVER['REQUEST_URI']);
parse_str($param_url['query'], $url_query);
$page=addslashes($url_query['page']);
$sort=addslashes($url_query['sort']);
$setting=mysqli_query($conn,"SELECT * FROM index_setting ORDER BY name ASC");
while ($r_s=mysqli_fetch_assoc($setting)) {
	$index_setting[$r_s['name']]=$r_s['value'];
}
if(!isset($_COOKIE['user_id'])){
	$box_account=$skin->skin_normal('skin/box_account_logout');
}else{
	$box_account=$skin->skin_normal('skin/box_account');
	$user_info=$class_member->user_info($conn,$_COOKIE['user_id']);
	$thongtin_coin=mysqli_query($conn,"SELECT *,count(*) AS total FROM jxsf8_paycoin WHERE account='{$user_info['loginName']}'");
	$r_c=mysqli_fetch_assoc($thongtin_coin);
	if($r_c['total']==0){
		$coin=0;
	}else{
		$coin=number_format($r_c['jbcoin']);
	}
}
$limit=30;
$menu=json_decode($class_index->list_menu($conn),true);
$slide=json_decode($class_index->list_slide($conn),true);
$replace=array(
	'header'=>$skin->skin_normal('skin/header'),
	'topbar'=>$skin->skin_normal('skin/topbar'),
	'box_menu'=>$skin->skin_normal('skin/box_menu'),
	'footer'=>$skin->skin_normal('skin/footer'),
	'script_footer'=>$skin->skin_normal('skin/script_footer'),
	'box_slide'=>$skin->skin_normal('skin/box_slide'),
	'box_account'=>$box_account,
	'title'=>$index_setting['title'],
	'description'=>$index_setting['description'],
	'site_name'=>$index_setting['site_name'],
	'limit'=>$limit,
	'list_sukien'=>$class_index->list_content_index($conn,2,5),
	'list_tintuc'=>$class_index->list_content_index($conn,1,5),
	'menu_left'=>$menu['menu_left'],
	'menu_right'=>$menu['menu_right'],
	'menu_tintuc'=>$menu['tintuc'],
	'menu_camnang'=>$menu['camnang'],
	'menu_canbiet'=>$menu['canbiet'],
	'menu_congdong'=>$menu['congdong'],
	'menu_footer'=>$menu['footer'],
	'slide_home_1'=>$slide['slide_home_1'],
	'slide_home_2'=>$slide['slide_home_2'],
	'tieude_home_2'=>$slide['tieude_home_2'],
	'menu_hotro'=>$menu['hotro'],
	'text_footer'=>$index_setting['text_footer'],
	'text_about'=>$index_setting['text_about'],
	'logo'=>$index_setting['logo'],
	'logo_footer'=>$index_setting['logo_footer'],
	'logo_center'=>$index_setting['logo_center'],
	'link_xem'=>$index_setting['link_domain'],
	'link_forum'=>$index_setting['link_forum'],
	'link_fb'=>$index_setting['link_fb'],
	'photo'=>$index_setting['photo'],
	'loginName'=>$user_info['loginName'],
	'Coin'=>$coin,
	);
echo $skin->skin_replace('skin/index',$replace);
?>