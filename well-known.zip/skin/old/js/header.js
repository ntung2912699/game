(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib.aaa = function() {
	this.initialize(img.aaa);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,95,381);


(lib.bg = function() {
	this.initialize(img.bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,740);


(lib._do = function() {
	this.initialize(img._do);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7,20);


(lib.image100 = function() {
	this.initialize(img.image100);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,220,242);


(lib.image102 = function() {
	this.initialize(img.image102);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,220,242);


(lib.image104 = function() {
	this.initialize(img.image104);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,220,242);


(lib.image106 = function() {
	this.initialize(img.image106);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,220,242);


(lib.image108 = function() {
	this.initialize(img.image108);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,220,242);


(lib.image110 = function() {
	this.initialize(img.image110);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,220,242);


(lib.image112 = function() {
	this.initialize(img.image112);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,220,242);


(lib.image114 = function() {
	this.initialize(img.image114);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,220,242);


(lib.image67 = function() {
	this.initialize(img.image67);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,42,39);


(lib.image70 = function() {
	this.initialize(img.image70);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,66,40);


(lib.image73 = function() {
	this.initialize(img.image73);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,22,16);


(lib.image76 = function() {
	this.initialize(img.image76);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,37,32);


(lib.image94 = function() {
	this.initialize(img.image94);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,220,242);


(lib.image96 = function() {
	this.initialize(img.image96);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,220,242);


(lib.image98 = function() {
	this.initialize(img.image98);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,220,242);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.aaa();
	this.instance.parent = this;
	this.instance.setTransform(4,-229.3,1.168,1.168,15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.2,-229.3,222.4,458.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.aaa();
	this.instance.parent = this;
	this.instance.setTransform(4,-229.4,1.168,1.168,15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.2,-229.4,222.4,458.8);


(lib.shape77 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image76, null, new cjs.Matrix2D(1,0,0,1,-18.5,-16)).s().p("Ai4CgIAAk/IFxAAIAAE/g");
	this.shape.setTransform(18.5,16);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,37,32);


(lib.shape74 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image73, null, new cjs.Matrix2D(1,0,0,1,-11,-8)).s().p("AhtBQIAAifIDbAAIAACfg");
	this.shape.setTransform(11,8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,22,16);


(lib.shape71 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image70, null, new cjs.Matrix2D(-1,0,0,-1,33,20)).s().p("AlJDIIAAmPIKTAAIAAGPg");
	this.shape.setTransform(64.6,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(31.6,19.4,66,40);


(lib.shape68 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image67, null, new cjs.Matrix2D(-1,0,0,-1,21,19.5)).s().p("AjRDDIAAmFIGjAAIAAGFg");
	this.shape.setTransform(35.1,25.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(14.1,5.6,42,39);


(lib.shape62 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E56D5F").s().p("AgMAMIABgQQAJgLANAFQAEAPgJAIg");
	this.shape.setTransform(0.2,1.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0.1,2.5,2.6);


(lib.shape61 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E56D5F").s().p("AgGALQgIgLAAgOQAPAEAJAKQAJAJgJAGg");
	this.shape.setTransform(0.3,1.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.1,-0.2,2.9,3.1);


(lib.shape60 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E56D5F").s().p("AgVAHQALgMAQgEIAQABIgQAMQgHAGgIAAQgGAAgGgDg");
	this.shape.setTransform(0.4,1.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.8,0.5,4.4,2);


(lib.shape59 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E56D5F").s().p("AgFgIIAHgOIAEATIgKAag");
	this.shape.setTransform(0.4,1.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,-0.8,1.2,4.6);


(lib.shape57 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E56D5F").s().p("AgTAdQgFgRACgVQAFgZARACQAcAEgFAWQgLAngSAAQgGAAgHgEg");
	this.shape.setTransform(5.2,3.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.9,0.7,4.8,6.6);


(lib.shape56 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E56D5F").s().p("AgVAUIgSgZIAmgRQAwAWgJAWg");
	this.shape.setTransform(5.3,3.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.3,1.5,8,4.5);


(lib.shape55 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E56D5F").s().p("AgsgYIAgABQAmALAUASIgrATQg5gXAKgag");
	this.shape.setTransform(6.2,5.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.6,2.9,9.3,5.1);


(lib.shape54 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E56D5F").s().p("AgnAWQAggNgBgCIAvgmIgKAtQgdASgSAAQgOAAgHgKg");
	this.shape.setTransform(5.7,4.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.8,1.4,7.9,6.4);


(lib.shape14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.204,1],-39,30.8,72.5,30.8).ss(1,0,0,3).p("AJLFcQgnAHjKg/QjLg/kSkiQkTkii0AE");
	this.shape.setTransform(58.7,39.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.176,1],-51.3,5.5,32.6,5.5).ss(1,0,0,3).p("AnDjyQBzAgBnA6QBmA7BJBWQBJBVBkBCQBlBBBlAQQBkARAkAA");
	this.shape_1.setTransform(53.3,24.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().ls(["rgba(25,10,13,0.086)","#190A0D","rgba(25,10,13,0)"],[0,0.208,1],-57.9,10.1,72.6,10.1).ss(1,0,0,3).p("AIZFEIg3gFQgtgHgrgNIiCgtIhZgrIhjg8IiAhmIinicQgjgjglggIg1gxQhQhMhwgY");
	this.shape_2.setTransform(57.2,35.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,119.4,76.1);


(lib.shape13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.204,1],-40.6,36.7,70.9,36.7).ss(1,0,0,3).p("AJZEYQhPAejyhBQjzhCj4jmQj4joiPgF");
	this.shape.setTransform(60.3,33.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.176,1],-51.3,5.5,32.6,5.5).ss(1,0,0,3).p("AnDjyQBzAgBnA6QBmA7BJBWQBJBVBkBCQBlBBBlAQQBkARAkAA");
	this.shape_1.setTransform(53.3,24.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().ls(["rgba(25,10,13,0.086)","#190A0D","rgba(25,10,13,0)"],[0,0.208,1],-56.3,16.4,74.2,16.4).ss(1,0,0,3).p("AoIkEQBwAYBQBMIBiBbQBBA+BvBbQA1ArA8AgQBwAzB2AiQB0AiB0gk");
	this.shape_2.setTransform(55.6,29.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,122.4,64.2);


(lib.shape12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.204,1],-41.8,39.3,69.7,39.3).ss(1,0,0,3).p("AJmEHQh1gNjvgsQjwgtj0jQQj1jSiPgF");
	this.shape.setTransform(61.5,30.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.176,1],-52.7,9.2,31.2,9.2).ss(1,0,0,3).p("AnRjMQByAgBgA/QBgA+BYBKQBWBLBmAoQBmApBhAJICXAN");
	this.shape_1.setTransform(54.7,20.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().ls(["rgba(25,10,13,0.086)","#190A0D","rgba(25,10,13,0)"],[0,0.208,1],-56.4,19.3,74.1,19.3).ss(1,0,0,3).p("AoJjnQBwAYBQBMIBiBbQBBA9BxBTQBwBSC0AaQC0AaAvgIIA4gE");
	this.shape_2.setTransform(55.7,26.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,124.9,59);


(lib.shape11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.204,1],-41.8,39.3,69.7,39.3).ss(1,0,0,3).p("AJmEHQhwgvjwg6Qjwg6j2iyQj4iziOgF");
	this.shape.setTransform(61.5,30.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.176,1],-55.1,11.7,28.8,11.7).ss(1,0,0,3).p("AnfizQBaAlBWAvICRBPQAfAOBqA2QBoA3ChAqQCgAqBMgQ");
	this.shape_1.setTransform(57.1,18);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().ls(["rgba(25,10,13,0.086)","#190A0D","rgba(25,10,13,0)"],[0,0.208,1],-56,17.6,74.5,17.6).ss(1,0,0,3).p("AoFj4QBwAYBQBMIBjBWQBEA6BzBCQByBCCOAPQCOAPBNAoQBNAoAFAL");
	this.shape_2.setTransform(55.3,28.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,124.9,59);


(lib.shape10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.204,1],-41.2,33.9,70.3,33.9).ss(1,0,0,3).p("AJdE/QhuhekiiCQkhiBjFiMQjFiMiCgC");
	this.shape.setTransform(60.9,36.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.176,1],-53.7,7.9,30.3,7.9).ss(1,0,0,3).p("AnYjYQBLAWAjASIAyAXQFcCICuBHQDWBZAuBM");
	this.shape_1.setTransform(55.7,21.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().ls(["rgba(25,10,13,0.086)","#190A0D","rgba(25,10,13,0)"],[0,0.208,1],-54.7,14.9,75.8,14.9).ss(1,0,0,3).p("AH2EVQgagcgfgUIgtgeQgOgJg5gaQg6gbiHgwIgBAAQiGgwhthBQhuhEhehSQhQhMhwgY");
	this.shape_2.setTransform(54,30.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-0.9,123.4,69.9);


(lib.shape9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.204,1],-39.2,28.6,72.3,28.6).ss(1,0,0,3).p("AJJF1QhDjPkdiOQkdiMjLh9QjMh+iBgC");
	this.shape.setTransform(58.9,41.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.176,1],-52.2,7.4,31.7,7.4).ss(1,0,0,3).p("AnOjeQGtBwDpB8QDqB9AZBY");
	this.shape_1.setTransform(54.2,22.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().ls(["rgba(25,10,13,0.086)","#190A0D","rgba(25,10,13,0)"],[0,0.208,1],-54.3,13.6,76.2,13.6).ss(1,0,0,3).p("AHyEhQgggigjgcIg6gwIhVg6QgXgNgYgMIluipQgigPghgSQgggRgegVIg1gqQhQhNhxgY");
	this.shape_2.setTransform(53.6,32.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,119.4,80.8);


(lib.shape8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.204,1],-37.1,24.6,74.4,24.6).ss(1,0,0,3).p("AIzGdQhbjqj/imInGkkQjJiAiBgC");
	this.shape.setTransform(56.8,45.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.176,1],-50.6,4.8,33.3,4.8).ss(1,0,0,3).p("Am+j5QE+BfDhCaQDhCYB7Bi");
	this.shape_1.setTransform(52.6,25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().ls(["rgba(25,10,13,0.086)","#190A0D","rgba(25,10,13,0)"],[0,0.208,1],-55.2,8.5,75.4,8.5).ss(1,0,0,3).p("An8lSQBwAYBRBNIA0AwQAxAuA6ApQBZA5BaA2QBVA1BTA4IDACCQBbA8AhAh");
	this.shape_2.setTransform(54.4,37.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,115.2,88.8);


(lib.shape7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.204,1],-36.1,23.3,75.4,23.3).ss(1,0,0,3).p("AIqGqQiSjMjkjIQjkjHi/iAQjAiAh+AL");
	this.shape.setTransform(55.8,46.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.176,1],-50.2,2.1,33.8,2.1).ss(1,0,0,3).p("Am6kTQEpBGDJDKQDJDJC5BO");
	this.shape_1.setTransform(52.2,27.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().ls(["rgba(25,10,13,0.086)","#190A0D","rgba(25,10,13,0)"],[0,0.208,1],-55.5,5.8,75,5.8).ss(1,0,0,3).p("AoAltQBxAYBSBPQBPBMBOBRQBWBZBhBLQBgBKBlBDQBkBCBLAoQBMAoAoAU");
	this.shape_2.setTransform(54.8,39.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,113.2,91.3);


(lib.shape6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.204,1],-35.4,22.1,76.1,22.1).ss(1,0,0,3).p("AIkG0QkAiei3jwQi2jvivh6Qiwh6h+AL");
	this.shape.setTransform(55.1,47.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["rgba(25,10,13,0.082)","#190A0D","rgba(25,10,13,0)"],[0,0.176,1],-49.9,0,34,0).ss(1,0,0,3).p("Am3koQEKArC1DzQC1DyD7BC");
	this.shape_1.setTransform(51.9,29.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().ls(["rgba(25,10,13,0.086)","#190A0D","rgba(25,10,13,0)"],[0,0.208,1],-55,4.1,75.5,4.1).ss(1,0,0,3).p("An7l/QCHAZBrBxQBqByBIBWQA2BBAUATQBbBVB+BUQB/BUCvBc");
	this.shape_2.setTransform(54.3,41.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,111.9,93.5);


(lib.shape115 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image114, null, new cjs.Matrix2D(1,0,0,1,-110,-121)).s().p("AxLS6MAAAglzMAiXAAAMAAAAlzg");
	this.shape.setTransform(136,185);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.shape113 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image112, null, new cjs.Matrix2D(1,0,0,1,-110,-121)).s().p("AxLS6MAAAglzMAiXAAAMAAAAlzg");
	this.shape.setTransform(136,185);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.shape111 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image110, null, new cjs.Matrix2D(1,0,0,1,-110,-121)).s().p("AxLS6MAAAglzMAiXAAAMAAAAlzg");
	this.shape.setTransform(136,185);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.shape109 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image108, null, new cjs.Matrix2D(1,0,0,1,-110,-121)).s().p("AxLS6MAAAglzMAiXAAAMAAAAlzg");
	this.shape.setTransform(136,185);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.shape107 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image106, null, new cjs.Matrix2D(1,0,0,1,-110,-121)).s().p("AxLS6MAAAglzMAiXAAAMAAAAlzg");
	this.shape.setTransform(136,185);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.shape105 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image104, null, new cjs.Matrix2D(1,0,0,1,-110,-121)).s().p("AxLS6MAAAglzMAiXAAAMAAAAlzg");
	this.shape.setTransform(136,185);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.shape103 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image102, null, new cjs.Matrix2D(1,0,0,1,-110,-121)).s().p("AxLS6MAAAglzMAiXAAAMAAAAlzg");
	this.shape.setTransform(136,185);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.shape101 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image100, null, new cjs.Matrix2D(1,0,0,1,-110,-121)).s().p("AxLS6MAAAglzMAiXAAAMAAAAlzg");
	this.shape.setTransform(136,185);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.shape99 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image98, null, new cjs.Matrix2D(1,0,0,1,-110,-121)).s().p("AxLS6MAAAglzMAiXAAAMAAAAlzg");
	this.shape.setTransform(136,185);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.shape97 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image96, null, new cjs.Matrix2D(1,0,0,1,-110,-121)).s().p("AxLS6MAAAglzMAiXAAAMAAAAlzg");
	this.shape.setTransform(136,185);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.shape95 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image94, null, new cjs.Matrix2D(1,0,0,1,-110,-121)).s().p("AxLS6MAAAglzMAiXAAAMAAAAlzg");
	this.shape.setTransform(136,185);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.shape5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFE8EC","#00A6FF","rgba(80,0,230,0.6)","rgba(69,43,255,0)"],[0.071,0.18,0.388,1],0,0,0,0,0,139.2).s().p("AvLHQQmTjAABkQQgBkPGTi/QGSjAI5AAQI5AAGTDAQGSC/AAEPQAAEQmSDAQmTC/o5AAQo5AAmSi/g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-137.4,-65.5,274.9,131);


(lib.shape4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFE8EC","#2FC7FF","rgba(0,0,223,0.6)","rgba(69,43,255,0)"],[0,0.231,0.388,1],20.9,17.6,0,20.9,17.6,67.7).s().p("AkckeIBggTIHZJjg");
	this.shape.setTransform(-27.7,-29.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.2,-60,57,61.2);


(lib.shape3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFE8EC","#2BA5FF","rgba(29,0,230,0.6)","rgba(101,43,255,0)"],[0,0.208,0.388,1],0,0,0,0,0,271.9).s().p("A9pA5QsTgYAAghQAAghMTgYQMRgXRYAAQRYAAMTAXQMSAYAAAhQAAAhsSAYQsTAYxYAAQxYAAsRgYg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-268.4,-8.1,537,16.3);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EBaZArIQgFAAgEgCQgGgDgFgFQgFAAgEgCQgYgKgRgSQgFAAgEgCQgfgSgegUQgFAAgEgCQgagOgPgYQgFAAgBgBQgFgSgJgLQgFAAgCgDQgSgbgPgeQgFAAgDgCQgMgNgKgPIAKAAIAAgKIAAgKIgKABQghABADggQAwAMAiAZQADADAFAAQAFAAACADQA5A/BqAOIAKAAQBMgBgugxQAAgFgCgCQgxgdhtAGQgFAAgDgDQhQhGiEgRIgKgBQgwgIg0AdQgFAAgFgBQjPg6ijhvQgFAAgDgCQgegegqgSQgFAAgBACQgHAPgRADQgFAAgBgCQgEgIAAgKQA0g6BEglIAAAFQCFAThRg0QgCgCAAgFQgFAAgDgCQgCgDAAgFQAcgkAUAKQACABAAAFQAPgTAjgBIAKAAQAAgFgCgEQgDgGgFgFIAKAAIAAgKQBCguAfgBIgRgEQgXgEAXgFIAAgKIAAgKQANAMAbgCIAKAAQAAgFgCgEQgDgGgFgFQE7B+EEByIgFgKIgUgoQgFAAgDgCQgzgxhRgTIgKAAQhMgEgsgkQgFAAgBgCQgEgIAAgKQAwgMAigZQADgDAFAAIAAgKQAqgIAUAQQADACAFAAQB3AaBtAmQACABAAAFQA/DJB8CNQADADAAAFQAKAKAHALQADAEAAAFQBBA8gFBkIAAAKQgUAPgWANQgDACgFAAQAAAFgDACQgbAcgoAPQAAAFgDADQgHAHgKAFIgBAKQgCARgRADIAAAKQAAAFgCAEQgRAbgLAiQAEAkAMAZIAEAJQhMgKhKhGgEAyPAl+QgFAAgFgBQgKgEgKgFQgFAAgDgDQgWgRgUgUIgKgBQghgCgHgbQAbAMAGgKQACgCAFAAIAAgKIAKAAQAXgGASgMQAEgCAFAAQAiAAASgRQADgDAFAAIAAgKIAUAAIAKAAIAAgKIAKAAIAKAAQAUAAATAFQABAAAAAFQAKgJAUgBIAKAAIAAgKQAQgBgFAVIgBAKQAFAAACgCQADgDAAgFIAAgKIAAgoQAVgGAEAPQAAABAFAAQAJgSAoADIABAFQAeAAAdgFQABAAAAgFIgKAAQg6gCgggcQBXAJAlgKIAGAVQAagOAMgbQACgEAAgFIAAgKIAAgoQAygQAbAmQADADAAAFQAFAFADAGQACAEAAAFQAVAJAMATQACACAFAAIAKAAQAAAFACACQA4AyhOADQAAAFgDADQguAwhlgGQAAAFgBAAQhrAWgqBTQgFAAgEADQgOAKgbgDQAAAFgBAAQgTAFgUAAIgKAAIgUAAIgKABIgPAAQgmAAgbgLgEAzpAisQAFgjgZgFIAAgKQA5AMgfAtQgBADgFAAIAAgKgEA2+AhfIgKALQgSAXgjADQAshAATAbgEA2xAh6QBVgIhVANgEAvbAhSIAAgKQA/AMA0ASIgFAAIgKABIgZABQgxAAgagWgEAyZAhRQkygXiuicQgFAAgFgCQgSgFgWgDIAAAKIAAAKQgFAAgEgDQgcgUgXgbQgFAAgEgCQgLgIAAgUQgFAAgDgDQgMgMgKgPQgFAAgCgCQgigqgTg4QgFAAgCgCQgegqgDhCIAAgKIAAgUQgFAAgCgDQgVgeAIg5IAKAAQAAgFgDgDQgHgNAAgTQAWADAGARQACAFAAAFQBFB+B2BNQADACAAAFQA4AiBAAYQAFACAFAAQBxAQB/AEIAKAAIAKAAIAKAAIAAgKQAoAFAIgaQACgEAAgFQAAgFgCgFQgTg2ABhMIAKAAQAogmBIBCQADACAFAAQAWASAlAHQABAAAAAFQAdgHAzAGIAKABQAFAAADgDQAdgZglg0QAAgFgCgBQgUgNgIgVQgFAAgBgCQgEgIAAgKQgFAAgDgCQgMgNgKgPIgKgBQg7gPgVg2IgKABQggAGgIgRIgKABIg8AJQAAAFgDADQgPAOgMASQgFAAgDACQgMANgUAFIgBAFQgsAFgtAAIAAAKQAFCLgtifQAAgFgCAAQgfgMgRgXIAAgFQgVABABgQQgFAAgBACQgmBWguhYQAAgFgCgDQgNgXgZgJQgFAAgDgCQgQgOAEgiQgFAAgDgDQgCgCAAgFIgKABQgRAAgXgpIgKAAIgUAAIgUAAQgZAAgPANQg+A0gwgZQAAgFgCgEQhMi8iYhxQgFAAgFgCQgegJgUgTQgFAAgFgBQgKgEgKgFQgFAAgFgBQhSgbhEgqIgKAAQgngHgVgXQgFAAgFgCQhugmhag8IgKAAIgKgBQhLgUg3gnQgFAAgFgBQglgMghgRQgFAAgFgCQgcgKgWgSQgFAAgFgCQgwgPggghQpIkFpPkFQpmkQqAj/QAAgFgCgBQkMiVk2hpQAAgFgCgBQk+iVlAiRQgFAAgFACQgSAFgggbQgFAAgEgCQlRiPlEibQgFAAgEgCIhvgwIgKABQgWAFACgQIgKgBQgUgEgKgPQgFAAgEgCQiahHidhDIgKgBQgUgEgKgPQgFAAgFgCQgugMgigaQgFAAgFgBQgmgMgWgbQgFAAgFgCQpYjqo6kIQgFAAgEgCQgfgSgegUQgFAAgEgCQi3hSiohgQgFAAgDgDQgHgHgFgKQgFAAgEgCQh+hEhzhQIgKAAQgRgDgDgRQgFAAgEgCQhug8hbhOQgFAAgEgCQhlhFhQhZQMMBzJuEOITmIgQJtENJ3ELQB5AzB5A2QBRAJA5AiQACACAAAFQJmEYJ3EPITiIZQJvELJ1ENQB5AzB5A2QAlACAfANQACAAAAAFQA4ATBAAKIAKABQAAgFgCgEQgQg6gChJQgFh8BVANIAKABQBXB7A9CTQACAFAAAFIBuAAIAKAAQAlAHAPgPQADgCAFAAIAAABIAAABIABAHQACAKgBAFQAJBJBDASQACAAAAAFIA+BEQADACAFAAQARAWAqADIABAFIAKAAQA8ggAJAqIABAKQBFAWgdgqIAHAEQA4AmAlggIAAgKQAFgFAGgDQAEgCAFAAIAAgKQARgDACgRIABgKQAAgFgCgEQgQgcgMghQgFAAgDgCQggghgegjQgFAAgDgDQhzhujZgHQgeAKgVASQhUBJgPhRIAKAAIAAgKIAAgUQAbg+A2gkQAEgCAFAAQAOgQAagDIAKgBIAAgKICMAAIAKAAQAoAAAnAFIABAFQAWAIAbAGQABABAAAFQB6AwBqBCQACABAAAFQAhAMAYAVQADACAAAFQAcAHAPAVQACACAFAAQAVAIAMAUQACACAFAAQAXgHASgLQAEgCAFAAQAAgFgCgEQgWg0gagxQgFAAgCgCQgfgpggglQgFAAgCgCQgQgZgRgXQAmAHAeARQACABAAAFQBvA7BMBdQADADAAAFQAFAFADAGQACAEAAAFQAQgBgFAVIgBAKQAfA/AuAyQADACAAAFQAYAtAhAlQADADAAAFQATAVAJAdQACAFAAAFQAZA3gXA3QgCAFAAAFQAAAFgCAEQgDAGgFAFIAAAoIAAAKIAAAyIAAAKIAAAKQATAAAMAIQAEACAFAAQA7AGgRAjQgCAEAAAFQAzgsAuAvQADACAAAFQAzAngXASQgDADgFAAQAAAPAEAOQABABAFAAQBogNg2A+QgKALAKAKQAFAAACADQADACAAAFQAdAKgUAIQgEACgFAAQgCAbAOAKQADADAFAAQAAAFgCABQgIAEgKAAQAAAFACADQAUAbgggPIAAAKQAFAKADAKQACAFAAAFQAAAFgCAEQgPAigNAlIAAAKIAAAKIgFAAQACAbgRADIAAgKQgFAAgCADQgSAVgPgYIgKgBQgigGgagNIAAAUIAAAKQAKAjAbATQADABAAAFQAFAAABACQAhA7gxgzQAAgFgDgCQgYgaghgRQARAggJAGQgDACgFAAQACA/AnAZQAEACAFAAIAKgFQgHBlgNhCQgFAAgEACQgGADgFAFIAAAKQAAAFgDADQgCACgFAAIAAAKIAAAKQAAAFgDADQgCACgFAAQgHAbAbgCIAAAFIAFAAQgTApgugfQgFAAgEgDQgLgIAAgTQgFAAgCgDIg1hNQgFAAgBgCQgNgdgVgTQgQALARAcQAvBMgmgPQAAgFgDgEQgxhGgchbQAjgGAJAYQABACAFAAIAAgKIAAgKIAKAAIAAgKIAoAJIAKABQAFAFAGADQAEACAFAAIAAgKQAFAAACgCQADgDAAgFIgKgBQgRgCAHgbIgKAAQgugBgsgJIgKAAIgUAAIAAAKQAAAFgDADIgvA+IAMAcQALBGhJgIQAQAnAOAUIgLAAQgcgCAnAhQAfAogUA9QgBAEAAAFQAFAAABgCIAEgIQA1AEhJAuIAAAKQAAAFgCABQg8AagSgWIgKAAQAAAFgDACQgrApgsgmQgFAAgDADQg5A1hVAYIgKgBgEAuLAgzQgigGgagNIAAgKQAjAKAhAOQACABAAAFIgKgBgEA5nAelQgCgCAAgFQAcAdgBAAQgCAAgXgWg");
	mask.setTransform(-13,-2.5);

	// Layer 1
	this.instance = new lib.Tween1();
	this.instance.parent = this;
	this.instance.setTransform(-714.5,-321.2,2.34,1,-33.2,0,0,-0.1,-0.1);
	this.instance.alpha = 0.789;
	this.instance.compositeOperation = "lighter";

	this.instance_1 = new lib.Tween2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(712.2,288.1,2.331,1);
	this.instance_1.alpha = 0.27;
	this.instance_1.compositeOperation = "lighter";
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,regX:0,regY:0,scaleX:2.33,rotation:0,x:712.2,y:288.1,alpha:0.27},107).wait(29).to({_off:false,regX:-0.1,regY:-0.1,scaleX:2.34,rotation:-33.2,x:-714.5,y:-321.2,alpha:0.648},75).wait(61));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:false},107).wait(29).to({rotation:-0.3,x:693.4,y:280.1},0).to({_off:true,regX:-0.1,regY:-0.1,scaleX:2.34,rotation:-33.2,x:-714.5,y:-321.2,alpha:0.648},75).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-623.5,-286.5,252.6,299.7);


(lib.sprite78 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape77("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite78, new cjs.Rectangle(0,0,37,32), null);


(lib.sprite75 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape74("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite75, new cjs.Rectangle(0,0,22,16), null);


(lib.sprite72 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape71("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite72, new cjs.Rectangle(31.6,19.4,66,40), null);


(lib.sprite69 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape68("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite69, new cjs.Rectangle(14.1,5.6,42,39), null);


(lib.sprite63 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape59("synched",0);
	this.instance.parent = this;

	this.instance_1 = new lib.shape60("synched",0);
	this.instance_1.parent = this;

	this.instance_2 = new lib.shape61("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.shape62("synched",0);
	this.instance_3.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,-0.8,1.2,4.6);


(lib.sprite58 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape54("synched",0);
	this.instance.parent = this;

	this.instance_1 = new lib.shape55("synched",0);
	this.instance_1.parent = this;

	this.instance_2 = new lib.shape56("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.shape57("synched",0);
	this.instance_3.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.8,1.4,7.9,6.4);


(lib.sprite15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib.shape6("synched",0);
	this.instance.parent = this;

	this.instance_1 = new lib.shape7("synched",0);
	this.instance_1.parent = this;

	this.instance_2 = new lib.shape8("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.shape9("synched",0);
	this.instance_3.parent = this;

	this.instance_4 = new lib.shape10("synched",0);
	this.instance_4.parent = this;

	this.instance_5 = new lib.shape11("synched",0);
	this.instance_5.parent = this;

	this.instance_6 = new lib.shape12("synched",0);
	this.instance_6.parent = this;

	this.instance_7 = new lib.shape13("synched",0);
	this.instance_7.parent = this;

	this.instance_8 = new lib.shape14("synched",0);
	this.instance_8.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},4).to({state:[{t:this.instance_2}]},5).to({state:[{t:this.instance_3}]},5).to({state:[{t:this.instance_4}]},5).to({state:[{t:this.instance_5}]},5).to({state:[{t:this.instance_6}]},5).to({state:[{t:this.instance_7}]},5).to({state:[{t:this.instance_8}]},5).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,111.9,93.5);


(lib.sprite116 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape95("synched",0);
	this.instance.parent = this;

	this.instance_1 = new lib.shape97("synched",0);
	this.instance_1.parent = this;

	this.instance_2 = new lib.shape99("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.shape101("synched",0);
	this.instance_3.parent = this;

	this.instance_4 = new lib.shape103("synched",0);
	this.instance_4.parent = this;

	this.instance_5 = new lib.shape105("synched",0);
	this.instance_5.parent = this;

	this.instance_6 = new lib.shape107("synched",0);
	this.instance_6.parent = this;

	this.instance_7 = new lib.shape109("synched",0);
	this.instance_7.parent = this;

	this.instance_8 = new lib.shape111("synched",0);
	this.instance_8.parent = this;

	this.instance_9 = new lib.shape113("synched",0);
	this.instance_9.parent = this;

	this.instance_10 = new lib.shape115("synched",0);
	this.instance_10.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_10}]},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26,64,220,242);


(lib.sprite6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 7
	this.instance = new lib.shape5("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0.7,0.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 6
	this.instance_1 = new lib.shape4("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.2,0.2,1.28,1.28,-81.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer 5
	this.instance_2 = new lib.shape4("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(0.2,0.2,1.28,1.28,173.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Layer 4
	this.instance_3 = new lib.shape4("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(0.2,0.2,0.841,0.841,60);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Layer 3
	this.instance_4 = new lib.shape4("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(0.2,0.2,0.811,0.811,0,41,49);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Layer 2
	this.instance_5 = new lib.shape4("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// Layer 1
	this.instance_6 = new lib.shape3("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(1.4,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite6, new cjs.Rectangle(-267.1,-69.8,537,139.1), null);


(lib.sprite79 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 7
	this.instance = new lib.sprite78();
	this.instance.parent = this;
	this.instance.setTransform(-93.3,134.4);
	this.instance.alpha = 0.238;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(43).to({_off:false},0).to({rotation:-24.2,guide:{path:[-93.2,134.3,58.1,66.2,191.8,-29,325.4,-124.2,443.5,-238.2,533.3,-324.9,614.7,-420.2,614.8,-420.2,614.8,-420.2]},alpha:1},29).to({scaleX:1,scaleY:1,rotation:-24.3,guide:{path:[614.7,-420.2,624.8,-432,634.9,-444,634.9,-444.1,634.9,-444.1]},alpha:0.961},1).to({rotation:-29,guide:{path:[634.9,-444.2,650.3,-462.6,665.4,-481.2,769,-610.1,860.2,-745.6,883.7,-780.6,908.1,-816.2,932.5,-851.9,955.8,-888.4,968.3,-908.2,980.3,-928.2,980.3,-928.3,980.3,-928.3]},alpha:0.328},15).to({scaleX:1,scaleY:1,rotation:-30,guide:{path:[980.3,-928.3,990.4,-945.3,1000.1,-962.5,1021.2,-1000,1038.2,-1038.7]},alpha:0.191},4).wait(1));

	// Layer 5
	this.instance_1 = new lib.sprite75();
	this.instance_1.parent = this;
	this.instance_1.setTransform(270.9,180.7);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(29).to({_off:false},0).to({x:892.3,y:-692.6},26).to({x:1152.9,y:-1058.8,alpha:0.281},16).to({_off:true},1).wait(21));

	// Layer 3
	this.instance_2 = new lib.sprite72();
	this.instance_2.parent = this;
	this.instance_2.setTransform(365,48.8);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(21).to({_off:false},0).to({x:972.3,y:-519.9},20).to({rotation:-13.5,x:1541.7,y:-1053.7,alpha:0.09},17).to({_off:true},1).wait(34));

	// Layer 1
	this.instance_3 = new lib.sprite69();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-16.3,-7.6);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:472.9,y:-379.1,alpha:1},11).to({x:550.4,y:-438.7,alpha:0.941},2).to({x:1402.3,y:-1094.3,alpha:0.27},19).to({_off:true},1).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.2,-2,42,39);


(lib.sprite64 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib.sprite63();
	this.instance.parent = this;
	this.instance.setTransform(10.4,-68.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[10.5,-68.7,68.8,-80.3,128.3,-90.6,187.8,-100.8,246.4,-114.2,305,-127.5,361.9,-146,418.8,-164.6,472,-192.7]}},51).to({_off:true},1).wait(78));

	// Layer 1
	this.instance_1 = new lib.sprite58();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-5.9,-6.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:343.6,y:-186.7},24).to({x:400.4,y:-248,alpha:0},8).to({_off:true},1).wait(97));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.9,-249,408.3,250.6);


(lib.sprite117 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.sprite116();
	this.instance.parent = this;
	this.instance.setTransform(4.6,-72.2);
	this.instance.alpha = 0.539;
	this.instance.compositeOperation = "lighter";

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite117, new cjs.Rectangle(30.6,-8.2,220,242), null);


(lib.sprite7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.sprite6();
	this.instance.parent = this;
	this.instance.setTransform(307.6,71,0.293,0.488);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.44,scaleY:0.73,alpha:0.109},1).to({scaleX:0.59,scaleY:0.97,alpha:0.211},1).to({scaleX:0.73,scaleY:1.21,alpha:0.32},1).to({scaleX:0.88,scaleY:1.46,x:307.5,alpha:0.43},1).to({scaleX:1.02,scaleY:1.7,y:70.9,alpha:0.539},1).to({scaleX:1.17,scaleY:1.94,y:71,alpha:0.641},1).to({scaleX:1.32,scaleY:2.18,alpha:0.75},1).to({scaleX:1.46,scaleY:2.42,alpha:0.859},1).to({scaleX:1.61,scaleY:2.67,x:307.6,alpha:0.961},1).to({scaleX:1.48,scaleY:2.42,y:70.9,alpha:0.859},3).to({scaleX:1.43,scaleY:2.34,y:71,alpha:0.82},1).to({scaleX:1.39,scaleY:2.26,alpha:0.789},1).to({scaleX:1.34,scaleY:2.17,alpha:0.75},1).to({scaleX:1.3,scaleY:2.09,alpha:0.719},1).to({scaleX:1.25,scaleY:2.01,x:307.7,alpha:0.691},1).to({scaleX:1.21,scaleY:1.93,x:307.6,alpha:0.66},1).to({scaleX:1.16,scaleY:1.84,y:71.1,alpha:0.629},1).to({scaleX:1.12,scaleY:1.76,alpha:0.59},1).to({scaleX:1.08,scaleY:1.68,y:71,alpha:0.551},1).to({scaleX:1.03,scaleY:1.6,alpha:0.52},1).to({scaleX:0.99,scaleY:1.51,alpha:0.48},1).to({scaleX:0.94,scaleY:1.43,alpha:0.449},1).to({scaleX:0.9,scaleY:1.35,y:70.9,alpha:0.41},1).to({scaleX:0.85,scaleY:1.27,y:71,alpha:0.379},1).to({scaleX:0.81,scaleY:1.19,x:307.5,y:70.9,alpha:0.34},1).to({scaleX:0.76,scaleY:1.1,x:307.6,alpha:0.309},1).to({scaleX:0.72,scaleY:1.02,alpha:0.281},1).to({scaleX:0.63,scaleY:0.86,y:71,alpha:0.211},2).to({scaleX:0.59,scaleY:0.77,y:71.1,alpha:0.18},1).to({scaleX:0.54,scaleY:0.69,y:71,alpha:0.141},1).to({scaleX:0.5,scaleY:0.61,alpha:0.109},1).to({scaleX:0.45,scaleY:0.53,alpha:0.07},1).to({scaleX:0.41,scaleY:0.45,alpha:0.039},1).wait(1).to({scaleX:0.36,scaleY:0.36,alpha:0},0).wait(16));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(229.2,36.3,157.5,72);


(lib.G10_flarandom31756_74951_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 9
	this.instance = new lib.sprite79();
	this.instance.parent = this;
	this.instance.setTransform(826.8,-14.7,0.523,0.523);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(37).to({_off:false},0).wait(22));

	// Layer 1
	this.instance_1 = new lib.sprite79();
	this.instance_1.parent = this;
	this.instance_1.setTransform(192.2,19.2,0.6,0.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(190.8,18,25.2,23.4);


(lib.G10_flarandom79858_74342_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 9
	this.instance = new lib.sprite64();
	this.instance.parent = this;
	this.instance.setTransform(5.9,69.6);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(100).to({_off:false},0).wait(14));

	// Layer 5
	this.instance_1 = new lib.sprite64();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-7.8,29.5,1,1,10.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(46).to({_off:false},0).wait(68));

	// Layer 1
	this.instance_2 = new lib.sprite64();
	this.instance_2.parent = this;
	this.instance_2.setTransform(5.9,69.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(114));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.8,0,15.6,71.1);


(lib.G10_flarandom81822_90342_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 31
	this.instance = new lib.G10_flarandom79858_74342_5();
	this.instance.parent = this;
	this.instance.setTransform(157.8,163.9,1,1,-24.9);
	this.instance._off = true;
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 0, 0, 0)];
	this.instance.cache(0,-2,20,75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(15).to({_off:false},0).wait(21));

	// Layer 21
	this.instance_1 = new lib.G10_flarandom79858_74342_5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(8.3,141,1.511,1.511,-18);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 0, 0, 0)];
	this.instance_1.cache(0,-2,20,75);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(36));

	// Layer 11
	this.instance_2 = new lib.G10_flarandom79858_74342_5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(261.4,121.5);
	this.instance_2._off = true;
	this.instance_2.filters = [new cjs.ColorFilter(0.46875, 0.46875, 0.46875, 1, 0, 0, 0, 0)];
	this.instance_2.cache(0,-2,20,75);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(28).to({_off:false},0).wait(8));

	// Layer 1
	this.instance_3 = new lib.G10_flarandom79858_74342_5();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-1.7,0);
	this.instance_3._off = true;
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 0, 0, 0)];
	this.instance_3.cache(0,-2,20,75);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(28).to({_off:false},0).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(31.4,132.9,24,109.4);


// stage content:
(lib.header = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 114 copy
	this.instance = new lib.G10_flarandom31756_74951_9();
	this.instance.parent = this;
	this.instance.setTransform(83.9,462.7,0.838,0.709,-30,0,0,0.1,0.1);
	this.instance.compositeOperation = "lighter";

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 8 copy
	this.instance_1 = new lib.G10_flarandom81822_90342_4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(164,335.9,0.838,0.709,-30);
	this.instance_1.alpha = 0.301;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer 114
	this.instance_2 = new lib.G10_flarandom31756_74951_9();
	this.instance_2.parent = this;
	this.instance_2.setTransform(354.3,700.2,1.47,1,-15);
	this.instance_2.compositeOperation = "lighter";

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Layer 8
	this.instance_3 = new lib.G10_flarandom81822_90342_4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(554,544.8,1.47,1,-15);
	this.instance_3.alpha = 0.301;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Layer 5
	this.instance_4 = new lib.sprite117();
	this.instance_4.parent = this;
	this.instance_4.setTransform(442.9,158,2.049,1.761,-21.7);
	this.instance_4.alpha = 0.539;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Layer 14
	this.instance_5 = new lib.sprite15();
	this.instance_5.parent = this;
	this.instance_5.setTransform(1329.5,256.5,0.946,1.172,0,-61.9,122.9,-0.1,0.1);
	this.instance_5.shadow = new cjs.Shadow("rgba(0,0,0,1)",0,0,5);

	this.instance_6 = new lib.sprite15();
	this.instance_6.parent = this;
	this.instance_6.setTransform(1238.4,189.6,0.946,1.172,0,14.2,-161.1,-0.1,0.1);
	this.instance_6.shadow = new cjs.Shadow("rgba(0,0,0,1)",0,0,5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5}]}).wait(1));

	// Layer 2
	this.instance_7 = new lib.sprite7();
	this.instance_7.parent = this;
	this.instance_7.setTransform(1230.1,99.6,0.078,0.059);
	this.instance_7.alpha = 0.672;
	this.instance_7.compositeOperation = "lighter";

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// Layer 2
	this.instance_8 = new lib.Symbol1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(1284.5,462.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// Layer 1
	this.instance_9 = new lib._do();
	this.instance_9.parent = this;
	this.instance_9.setTransform(997,360);

	this.instance_10 = new lib.bg();
	this.instance_10.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1000,176.8,2000,955.3);
// library properties:
lib.properties = {
	width: 2000,
	height: 740,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"/skin/css/images/header/aaa.png?1480910335399", id:"aaa"},
		{src:"/skin/css/images/header/bg.jpg?1480910335399", id:"bg"},
		{src:"/skin/css/images/header/_do.png?1480910335399", id:"_do"},
		{src:"/skin/css/images/header/image100.jpg?1480910335399", id:"image100"},
		{src:"/skin/css/images/header/image102.jpg?1480910335399", id:"image102"},
		{src:"/skin/css/images/header/image104.jpg?1480910335399", id:"image104"},
		{src:"/skin/css/images/header/image106.jpg?1480910335399", id:"image106"},
		{src:"/skin/css/images/header/image108.jpg?1480910335399", id:"image108"},
		{src:"/skin/css/images/header/image110.jpg?1480910335399", id:"image110"},
		{src:"/skin/css/images/header/image112.jpg?1480910335399", id:"image112"},
		{src:"/skin/css/images/header/image114.jpg?1480910335399", id:"image114"},
		{src:"/skin/css/images/header/image67.png?1480910335399", id:"image67"},
		{src:"/skin/css/images/header/image70.png?1480910335399", id:"image70"},
		{src:"/skin/css/images/header/image73.png?1480910335399", id:"image73"},
		{src:"/skin/css/images/header/image76.png?1480910335399", id:"image76"},
		{src:"/skin/css/images/header/image94.jpg?1480910335399", id:"image94"},
		{src:"/skin/css/images/header/image96.jpg?1480910335399", id:"image96"},
		{src:"/skin/css/images/header/image98.jpg?1480910335399", id:"image98"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;